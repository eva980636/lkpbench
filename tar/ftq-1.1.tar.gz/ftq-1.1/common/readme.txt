This file is from FFTW, and is redistributable with it's original copyright
notice and license left in the file.  
