# These are switches to enable/disable some tests.

# Suspend tests
export suspend_dbus=0
export suspend_pmsuspend=1
export suspend_mem=1
export suspend_ac=0
export suspend_power=0

# Disable hotplugging cpu0 by default
hotplug_allow_cpu0=0
